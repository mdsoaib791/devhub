import AuthForm from "@/components/features/auth-form";

export default function Home() {
  return (
    <AuthForm />
  );
}

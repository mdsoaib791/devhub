'use client'
import DevelopersWrapper from "@/components/developer"

function Developers() {
  return (
    <DevelopersWrapper />
  )
}

export default Developers

import DeveloperAddUpdateForm from "@/components/developer/addupdate"

function ManageDeveloper() {
  return (
    <div>
      <DeveloperAddUpdateForm />
    </div>
  )
}

export default ManageDeveloper

export interface BlogModel {
  developer_id: string;
  title: string;
  excerpt: string;
  content: string;
  is_public: boolean;
}

export const IOCTYPES = {
  IDeveloperService: Symbol.for("IDeveloperService"),
  IUnitOfService: Symbol.for("IUnitOfService"),
  // ...other types if needed
};


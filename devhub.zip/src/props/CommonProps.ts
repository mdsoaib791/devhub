export default interface CommonProps {
  children?: React.ReactNode;
}

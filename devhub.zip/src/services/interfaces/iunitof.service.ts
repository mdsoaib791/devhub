
import IDeveloperService from './ideveloper.service'; // Add this import

export default interface IUnitOfService {
  DeveloperService: IDeveloperService; // Add this line
}

export enum StatusValues {
  Published = 'Published',
  Draft = 'Draft',
  Trash = 'Trash',
  Reject = 'Rejected',
  InReview = 'InReview',
}

export enum Roles {
  ALL = 'All',
  ADMINISTRATOR = 'Administrator',
  STUDENT = 'Student',
  EMPLOYER = 'Employer',
  AFFILIATE = 'Affiliate',
}

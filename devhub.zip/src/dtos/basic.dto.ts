export default interface BasicDto {
  id: number;
  name: string;
  isMapped: boolean;
}

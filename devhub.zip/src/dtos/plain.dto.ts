export default interface PlainDto {
  message: string;
  count: number;
}
